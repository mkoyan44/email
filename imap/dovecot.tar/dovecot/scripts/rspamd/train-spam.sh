rspamc -h virus.sysnet.local:11332 learn_spam
